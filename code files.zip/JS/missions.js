class missions{
	#missionObjective= "NULL";//mission goals
	#missionName="NULL";
	#missionDescription="NULL";//exactly what the mission is about

	//where it is situated within the story 
	#missionFile="NULL";//this is an html file that redirects you
	//to the place where you are going to complete the missions
	
	//requirements of mission
	//levels are not classes they are calculated values, XP
	#requiredXP=0;
	#COM_enemies =0;
	#subMissions=0;//still uses mission class 
	
	//completion
	#loot_to_be_collected=0;
	#card_to_be_collected_name="NULL";
	#Defeated_COM_count=0;
	#COM_boss_count=0;
	//use combat class to determine if COM bosses and enemies defeated 
	//include tribal territories on map
	 
	//note that the environement can be designed  to store surprises 
	//for checkpoints they are messages that save your player progress
	//no mission porgress are saved. Each mission neeeds to be completed in 
	//one go 
	
	#XP_Boost=0.0;
	#mission_points=0;

	constructor(name, objective, description, file){
		this.#missionObjective=objective;
		this.#missionName=name;
		this.#missionFile=file;
		this.#missionDescription=description;
	}
	
	
	SetAttributes(value, attribute){
		switch(attribute){
			case "requiredXP":
				if(value>=0){
				this.#requiredXP= value;}
				break;
			case "subMissions":
				if(value>=0){
				this.#subMissions=value;}
				break;
			case "COM_enemies":
				if(value>=0){
				this.#COM_enemies=value;}
				break;
			case "loot_to_be_collected":
				if(value>=0){
				this.#loot_to_be_collected=value;}
				break;
			case "card_to_be_collected_name": 
				this.#card_to_be_collected_name=value;
				break;
			case "Defeated_COM_count":
				if(value>=0){
				this.#Defeated_COM_count=value;}
				break;
			case "COM_boss_count":
				if(value>=0){
				this.#COM_boss_count=value;}
				break;
			case "XP_Boost":
				if(value>=0){
				this.#XP_Boost=value;}
				break;
			case "mission_points":
				if(value>=0){
				this.#mission_points=value;}
				break;
		}
	}		
	

    Getters(attribute){
		switch(attribute){
			case "requiredXP":
				return this.#requiredXP;
				break;
			case "subMissions":
				return this.#subMissions;
				break;
			case "COM_enemies":
				return this.#COM_enemies;
				break;
			case "loot_to_be_collected":
				return this.#loot_to_be_collected;
				break;
			case "card_to_be_collected_name":
				return this.#card_to_be_collected_name;
				break;
			case "Defeated_COM_count":
				return this.#Defeated_COM_count;
				break;
			case "COM_boss_count":
				return this.#COM_boss_count;
				break;
			case "XP_Boost":
				return this.#XP_Boost;
				break;
			case "mission_points":
				return this.#mission_points;
				break;
			case "missionDescription":
				return this.#missionDescription;
				break;
			case "missionObjective":
				return this.#missionObjective;
				break;
			case "missionName":
				return this.#missionName;
				break;
			case "missionFile":
				return this.#missionFile;
				break;
		}
	}
}
//write your code under here
player = new missions("The beginning", "Get the background story of Hall Lu","find something cool","forest.html");
console.log(player.Getters("missionDescription"));
console.log(player.Getters("missionFile"));
player.SetAttributes(5,"submissions");
console.log(player.Getters("subMissions"));
        
		player1= new score();
		console.log(player1.getter("missionPoints"));
        player1.updateAttribute(5,"missionPoints");
		console.log(player1.getter("missionPoints"));
