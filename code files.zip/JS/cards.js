class cards{
	#name ="NULL";
	#type="Card";
	#LevelRequired=0;
	#BoostRate=0;
	#TokensNeeded=0;
	//description of cards should be made 
	elementValue="NULL";
	//actual card picture too
	#Points=0;//how much mission points 
	#Flags=0;//means damage actually
	#CounterPoints=0;//how much damage it causes on the player using the 
	//YOU WILL NEED TO CHECK EACH TIME IF PLAYER HAS ENOUGH TO GET INTO THE CERTAIN LEAGUE
	//IF PLAYER IN THE LEAGUE THEIR CARD CAN BE UPDATED
	constructor(){}
	set(property,value){
		switch(property){
			case "name":
				this.#name=value;
				break;
			case "type":
				this.#type=value;
				break;
			case "LevelRequired":
				this.#LevelRequired=value;
				break;
			case "BoostRate":
				this.#BoostRate=value;
				break;
			case "TokensNeeded":
				this.#TokensNeeded=value;
				break;
			case "Flags":
				this.#Flags=value;
				break;
			case "CounterPoints":
				this.#CounterPoints=value;
				break;
		    case "Points":
				this.#Points=value;
				break;}
		}		
	
	getter(property){
		switch(property){
			case "name":
				return this.#name;
				break;
			case "type":
				return this.#type;
				break;
			case "LevelRequired":
				return this.#LevelRequired;
				break;
			case "BoostRate":
				return this.#BoostRate;
				break;
			case "TokensNeeded":
				return this.#TokensNeeded;
				break;
			case "Flags":
				return this.#Flags;
				break;
			case "CounterPoints":
				return this.#CounterPoints;
				break;
		    case "Points":
				return this.#Points;
				break;
		}		
}
attack(){
	//check the type right here 
	//accordin to type you
	//send an attack accordingly
	
}
}

	
player=new cards();
console.log(player.getter("Points"));
player.set("Flags",6);
console.log(player.getter("Flags"));
player.set("type","element");
if (player.getter("type")=="element"){
player.elementValue="fire";
console.log(player.elementValue);}

