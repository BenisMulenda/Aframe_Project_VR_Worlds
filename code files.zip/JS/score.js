class score{
		#missionPoints=0;
		 #XP=0;//helps you check which level you are at
		 #tokens=0;
		 #netPoints=0;
		 #boost=0;//allows you to boost score by multiples 
		 #lootPoints=0;
		 #elementPoints=0;
	
	constructor(){
	}
	
	calculatePoints(){
		return this.#XP+this.#tokens+this.#netPoints+this.#missionPoints+this.#lootPoints+this.#elementPoints;
		}//used to check player rankings 
		
	updateAttribute(value, attribute){
		switch(attribute){
			case "missionPoints":
				if(this.#missionPoints+value>=0){
				this.#missionPoints+=value;}
				break;
			case "XP":
				if(this.#XP+value>=0){
				this.#XP+=value;}
				break;
			case "tokens":
				if(this.#tokens+value>=0){
				this.#tokens+=value;}
				break;
			case "netPoints":
				if(this.#netPoints+value>=0){
				this.#netPoints+=value;}
				break;
			case "boost":
				if(this.#boost+value>=0){
				this.#boost+=value;}
				break;
			case "lootPoints":
				if(this.#lootPoints+value>=0){
				this.#lootPoints+=value;}
				break;
			case "elementPoints":
				if(this.#elementPoints+value>=0){
				this.#elementPoints+=value;}
				break;
		}
	}		
	
	getter(attribute){
		switch(attribute){
			case "missionPoints":
				return this.#missionPoints;
				break;
			case "XP":
				return this.#XP;
				break;
			case "tokens":
				return this.#tokens;
				break;
			case "netPoints":
				return this.#netPoints;
				break;
			case "boost":
				return this.#boost;
				break;
			case "lootPoints":
				return this.#lootPoints;
				break;
			case "elementPoints":
				return this.#elementPoints;
				break;
		}
	}	
}
		player= new score();
		console.log(player.getter("missionPoints"));
	    player.updateAttribute(5,"missionPoints");
		console.log(player.getter("missionPoints"));
		player.updateAttribute(0.9,"boost");
		console.log(player.getter("boost"));
		console.log(player.calculatePoints());