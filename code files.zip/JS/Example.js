//Guide for the JavaScript Department
//-----------------------------------------------------------------------------------
// JS is foundational and creates the in-game interactions that we desire with the players
// Creativity is needed to expand the given classes to better suit the desired outcomes 
// Additional functions could be added to enable transistions to sub-missions
// ID and property manipulations are very essential to create an interactive environment on A-frame
// AI enemies are computerized, algorithms have to be designed to ensure they act accordingly
 // - for instance to ensure that a character's movement is restricted to a certain area, AI has to be implemented
 // - Another example is transport systems as well as animation
 
 /* Below are a list possible tasks that will be completed using JS/Visuals:
    = Opening of doors (manipulations of the positio property)
	= Icons visibility (can also be done on A-frame)
	= AI enemies
	= Transport systems
	= Animations 
	= Character generation
	= Change in setting 
	= Cameras */
 

//1st Mission
//=======================================================================================================================================
//====Description Sequences=====//
//You are awaken from the capsule
//You are required to take a bus to get to Linda who is in the Greenhouse with Nomsa
//You are told to follow Linda and Nomsa closely
//Linda tells you to check around the Asylum to see if anyone needs help
//This mission will earn you two points
//finally you make your way out of the Greenhouse
//======Base Code==========//
Greenhouse = new missions("Woke: Greenhouse", "Awake and find Linda in the Greenhouse", "The player awakes from one of the capsules and is required  to use a bus to get to Linda, and is told to follow closely. The player has to find their way out of the Greenhouse.", "");
//Understanding  of the breakdown is crucial
//Instensive use of comments is needed, we need descriptions to understand what was the intended purpose of a certain line 
//of code
Greenhouse.SetAttributes(1,"subMissions");
Greenhouse.SetAttributes(0,"COM_enemies");
//certain missions do not have a direct way of ending in those cases 
//functions will have to be created to end the particular missions 
Greenhouse.SetAttributes("none","card_to_be_collected_name");
Greenhouse.SetAttributes(0,"loot_to_be_collected");//there is no loot in this mission 
Greenhouse.SetAttributes(0.03,"XP_Boost");
Greenhouse.SetAttributes(0,"COM_boss_count");
/*
The updating the attrbutes below depends on the user's interaction as well. COM defeated means
how many COMs did the player defeats for that mission. If no COMs you leave it blank

Greenhouse.SetAttributes(0,"Defeated_COM_count");
*/

//Do not specify mission points, that system has not yet been designed. It will be added on a later stage

/* Honestly I am unsure what the code below is, you need to add comments

BusStop = new missions("Woke Part 1", "you are awaken from your capsule, then after you are required to take a bus to get to the Greenhouse", "In order to get to the Greenhouse you have to get a bus.","BusStop.html");
BusStop.SetAttributes("none","card_to_be_collected_name");
BusStop.SetAttributes("none","card_to_be_given_name");
BusStop.SetAttributes(2, "mission_points");
*/ 
//=======Additional functions go below=======//

//Example of how to end a mission without COM objects 
//let's say we declared a character called Linda and her id= "Linda" since she is a object we will use 
//A-frame properties, our designed AI works like this Linda speaks and moves to a certain position
//let's call that position x y z, when Linda reaches there mission is over
/*
  I am writing the code as a comment because it wouldn't run because Linda does not exist yet
 
 function EndGame(){
	var Linda = document.getElementById("Linda");
	var x = 10, y =5, z=-1;//end position
  
	while (true){//makes sure it runs continuously
		var pos = Linda.getAttribute("position"); //you need to learn Aframe JS properties, it is a coincidence that it looks similar to our missions class 
		if (pos.x == x && pos.y == y && pos.z == z){//testing if she is at the wanted position 
			return "END";
			break;
		}
		else{
			continue;
		}
	}
  }
  
the function above is functional but not efficient. Guess why?
*/

/*
 You do not have to repeat this
 
Greenhouse = new missions("Woke: Greenhouse", "Awake and find Linda in the Greenhouse", "The player awakes from one of the capsules and is required  to use a bus to get to Linda, and is told to follow closely. The player has to find their way out of the Greenhouse.", "Greenhouse.html");
Greenhouse.SetAttributes(1,"subMissions");
Greenhouse.SetAttributes(0,"COM_enemies");//(not required) recurring at randomized intervals
Greenhouse.SetAttributes("none","card_to_be_collected_name");
Greenhouse.SetAttributes(0,"loot_to_be_collected");//there is no loot in this mission 
Greenhouse.SetAttributes(0,"Defeated_COM_count");
Greenhouse.SetAttributes(0,"COM_boss_count");//There are no bosses in this mission
Greenhouse.SetAttributes(0.02,"XP_Boost");*/

//=======================Submissions==================//
Acknowledged = new missions("Woke Part 2", "follow Linda and Nomsa closely, Linda tells you to check around the Asylum to see if anyone needs help","Acknowledged.html");
Acknowledged.SetAttributes("none","card_to_be_collected_name");

//Acknowledged.SetAttributes("none","card_to_be_given_name");//This does not exist
//Acknowledged.SetAttributes(2, "mission_points");

//END!

//2nd Mission
//===========================Testing======================================//
console.log("The 1st mission's name is: " + Greenhouse.Getters("missionName"));
console.log("The 1st mission's description is: " + Greenhouse.Getters("missionDescription"));

if (Greenhouse.Getters("missionFile")== ""){
	console.log("The 1st mission's file is: <none>");
}
else{
	console.log("The 1st mission's file is: " + Greenhouse.Getters("missionFile"));
}
console.log("The 1st mission's number of submissions is: " + Greenhouse.Getters("submissions"));
console.log("The testing is complete!");


//Please do not code each mission in different files. You are allowed to code up to 6 missions with their 
//submissions on 1 file, name the files according to where those missions will take place e.g. Asylum(0).js, Asylum(1).js and Frozen(1).js
//NOTE: ensure that each file is a maximum of 1300 lines before making a new file