class player {
	//personal information
	#Name="NULL";
	#XP=800;
	#Color="#ffffff";
	#playerID="NULL";
	#health=4;//4 hearts to indicate health 
	#level=2;
	
	//cards check by type
	#myInventory= [];//cards can be cars and other things too
	#myMinions= [];//creates a minion
	#myAbility=[];//makes your player better
	#myElement= [];//Allows multipliers
	#Others= [];//

	#missions_completed=[];//you need sql to store missions completed 
	//names of missions will be recorded 

	constructor(username, color, p_ID){
		this.#Name=username;
		this.#Color=color;
		this.#playerID=p_ID;
	}

    getXP() {
        return this.#XP;
    }

    getInventory() {
        return this.#myInventory;
    }

    getMinion() {
        return this.#myMinions;
    }

    getElement() {
        return this.#myElement;
    }

    getAbility() {
        return this.#myAbility;
    }

    getOthers() {
        return this.#Others;
    }

    getInfo(attribute) {
        switch (attribute) {
            case "Name":
                return this.#Name;
                break;
            case "health":
                return this.#health;
                break;
            case "level":
                return this.#level;
                break;
			case "XP":
				return this.#XP;
				break;
            
        }
    }
}

benis = new player("Benis", "white", "p1092");
console.log(benis.getInfo("Name"));
console.log("Player Points: " + benis.getStats().getter("missionPoints"));
benis.getStats().updateAttribute(5, "missionPoints");
console.log("Player Points: " + benis.getStats().getter("missionPoints"));
benis.getInventory()[0] = new cards();
benis.getInventory()[0].set("name", "weapons");
//console.log("Testing array: "+ benis.getInventory()[1].getter("name"));
console.log("Testing array: " + benis.getInventory()[0].getter("name"));
