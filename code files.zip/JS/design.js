//getting the face

function hair(){
	var centre= document.getElementById("face").getAttribute('position');
	var angle =[(Math.PI)/6, (Math.PI)/4, (Math.PI)/3, (Math.PI)/2];//YZ
	var b, i, pos_x, pos_y, pos_z;
	var radius=document.getElementById("face").getAttribute('radius');
	
	for (i=0; i < 4; i++){
	//setting the hair particle to the correct starting point 
	//regardless of where they are
	//dealing YZ plane only
	var id="Particle" + i;
	//setting position of all particles
	var out_pos= centre.x+' '+centre.y +' '+centre.z;


	document.getElementById(id).setAttribute('color','black');
	document.getElementById(id).setAttribute('position',out_pos);
    
	//trialing with the new position
	pos_y= centre.y+ ( radius * Math.sin(angle[i]));
	pos_z= centre.z+ ( radius * Math.cos(angle[i]));
	
	//setting new positions of hair particles
	out_pos=  document.getElementById("face").getAttribute('position').x +' '+pos_y +' '+pos_z;
	document.getElementById(id).setAttribute('position',out_pos);

	}
	//dealing with a combination of the xyz ====
	
	for(b=0; b<4;b++){
		
	var id="Part" + b;
	out_pos= centre.x+' '+centre.y +' '+centre.z;
	document.getElementById(id).setAttribute('color','black');
	document.getElementById(id).setAttribute('position',out_pos);

	pos_y= centre.y+ ( radius * Math.sin(angle[b]) * Math.sin(angle[b]) );
	pos_z= centre.z+ (radius * Math.cos(angle[b]));
	pos_x=centre.x + ( radius * Math.cos(Math.PI/3));
	
	//setting new positions of hair particles
	out_pos=  pos_x +' '+pos_y +' '+pos_z;
	document.getElementById(id).setAttribute('position',out_pos);
	
	}
	
	for(b=0; b<4;b++){
		
	var id="PartA" + b;
	out_pos= centre.x+' '+centre.y +' '+centre.z;
	document.getElementById(id).setAttribute('color','black');
	document.getElementById(id).setAttribute('position',out_pos);

	pos_y= centre.y+ ( radius * Math.sin(angle[b]) * Math.sin(angle[b]) );
	pos_z= centre.z+ (radius * Math.cos(angle[b]));
	pos_x=centre.x + ( radius * Math.cos((2*Math.PI)/3));
	
	//setting new positions of hair particles
	out_pos=  pos_x +' '+pos_y +' '+pos_z;
	document.getElementById(id).setAttribute('position',out_pos);
	
	}
	
	for(b=0; b<4;b++){
		
	var id="PartB" + b;
	out_pos= centre.x+' '+centre.y +' '+centre.z;
	document.getElementById(id).setAttribute('color','black');
	document.getElementById(id).setAttribute('position',out_pos);

	pos_y= centre.y+ (radius * Math.sin(angle[b]) * Math.sin(angle[b]) * Math.sin(angle[b]) );
	pos_z= centre.z+ (radius * Math.cos(angle[b]));
	pos_x=centre.x + (radius * Math.cos((Math.PI)/4));
	
	//setting new positions of hair particles
	out_pos=  pos_x +' '+pos_y +' '+pos_z;
	document.getElementById(id).setAttribute('position',out_pos);
	
	}

	for(b=0; b<4;b++){
		
	var id="PartC" + b;
	out_pos= centre.x+' '+centre.y +' '+centre.z;
	document.getElementById(id).setAttribute('color','black');
	document.getElementById(id).setAttribute('position',out_pos);

	pos_y= centre.y+ (radius * Math.sin(angle[b]) * Math.sin(angle[b]) * Math.sin(angle[b]) );
	pos_z= centre.z+ (radius * Math.cos(angle[b]));
	pos_x=centre.x + (radius * Math.cos((3*Math.PI)/4));
	
	//setting new positions of hair particles
	out_pos=  pos_x +' '+pos_y +' '+pos_z;
	document.getElementById(id).setAttribute('position',out_pos);
	
	}

}